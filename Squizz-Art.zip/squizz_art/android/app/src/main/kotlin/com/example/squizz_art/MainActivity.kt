package com.example.squizz_art

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
